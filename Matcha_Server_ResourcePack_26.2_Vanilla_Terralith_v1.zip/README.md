# Matcha Server Resource Pack 26.2 – Vanilla + Terralith

This server resource pack is the vanilla-visual counterpart of Matcha
Flavoured 1.12 for Minecraft Java 26.2.

It is derived from the supplied upstream `Vanilla Flavoured` resource pack and
the matching full Matcha 1.12 assets. Neither source directory is modified.

## Purpose

- Keep vanilla Minecraft block, item, foliage and interface visuals wherever
  Matcha does not need a dedicated asset.
- Keep all Matcha custom gameplay models, textures, sounds, fonts and names.
- Bring the older Vanilla Flavoured 1.11 package forward to the Matcha 1.12
  gameplay version used by this server.
- Remain compatible with Terralith biome climate colours without purple or
  debug-colour foliage.

## Matcha 1.12 backport additions

Compared with the supplied Vanilla Flavoured 1.11 pack, this package adds the
1.12 copper-tool oxidation model logic for:

- copper axe, hoe, pickaxe, shovel and sword;
- Matcha copper dolabra, mattock and shears.

It also adds their exposed, weathered and oxidized models/textures, updates the
custom dolabra/mattock textures changed in 1.12, and uses Matcha 1.12's language
files.

## Terralith colours

This package intentionally contains no custom `grass.png`, `foliage.png` or
`dry_foliage.png` colormap. Minecraft therefore uses its own vanilla 26.2
climate maps for every vanilla and Terralith biome. This is the most faithful
vanilla-looking option and cannot select the purple placeholder pixel present
in the full Matcha colormap.

## Deliberately excluded

- Matcha's cosmetic replacements for ordinary vanilla blocks and items;
- Matcha's custom grass/foliage colour maps;
- the invalid upstream debug copy `netherite - Copy.png`;
- all server-side `data` content (this ZIP is a client resource pack only).

## Installation

Host the ZIP at a direct-download URL and configure `server.properties` with
the SHA-1 and resource-pack UUID recorded in the adjacent
`Matcha_Server_ResourcePack_26.2_Vanilla_Terralith_v1_SERVER_PROPERTIES.txt`.

Do not place this resource pack in `world/datapacks`.
