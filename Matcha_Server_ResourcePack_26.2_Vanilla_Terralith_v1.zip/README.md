# Matcha Server Resource Pack 26.2 – Vanilla + Terralith

This server resource pack is the vanilla-visual counterpart of Matcha
Flavoured 1.12 for Minecraft Java 26.2.

It is derived from the supplied upstream `Vanilla Flavoured` resource pack and
the matching full Matcha 1.12 assets. Neither source directory is modified.

## Purpose

- Keep vanilla Minecraft block, item, foliage and interface visuals wherever
  Matcha does not need a dedicated asset.
- Keep all Matcha custom gameplay models, textures, sounds, fonts and names.
- Keep Matcha visuals for vanilla IDs whose gameplay identity was changed
  (including Obols, ores, tools, armour, foods and workstation blocks), while
  ordinary cosmetic replacements remain vanilla.
- Bring the older Vanilla Flavoured 1.11 package forward to the Matcha 1.12
  gameplay version used by this server.
- Remain compatible with Terralith biome climate colours without purple or
  debug-colour foliage.

## Matcha 1.12 backport additions

Compared with the supplied Vanilla Flavoured 1.11 pack, this package adds the
1.12 copper-tool oxidation model logic for:

- copper axe, hoe, pickaxe, shovel and sword;
- Matcha copper dolabra, mattock and shears.

It also adds their exposed, weathered and oxidized models/textures, updates the
custom dolabra/mattock textures changed in 1.12, and uses Matcha 1.12's language
files.

The 26.2 audit also restored the five base copper-tool models and textures that
were unintentionally falling back to the 26.2 client, and connected Matcha's
unused small/big placeholder-fish artwork to the otherwise missing active
`blind_minnow` and `blind_cave_fish` item models.

## Terralith colours

This package intentionally contains no custom `grass.png`, `foliage.png` or
`dry_foliage.png` colormap. Minecraft therefore uses its own vanilla 26.2
climate maps for every vanilla and Terralith biome. This is the most faithful
vanilla-looking option and cannot select the purple placeholder pixel present
in the full Matcha colormap.

## Dungeons and Taverns assets

This package also contains the client assets shipped inside Dungeons and
Taverns v5. Datapacks installed under `world/datapacks` do not automatically
send their `assets` directory to players, so these files are required here for
the DnT keys, charts, item models, textures, translations and potion names to
render correctly.

The chart assets are actively used by pack `26`: twelve navigation-only charts
can drop from selected boss rewards or Matcha ominous-unique loot and unfold
into locator maps in their target dimension. No tavern quest trader is active.

The upstream Korean DnT language file contained one missing closing quote in
the catacomb-chart entry. Only this resource-pack copy was corrected; the
downloaded DnT datapack remains unchanged.

## Deliberately excluded

- Matcha's cosmetic replacements for ordinary vanilla blocks and items,
  except replacements required to match changed gameplay names or mechanics;
- Matcha's custom grass/foliage colour maps;
- the invalid upstream debug copy `netherite - Copy.png`;
- all server-side `data` content (this ZIP is a client resource pack only).

## Installation

Host the ZIP at a direct-download URL and configure `server.properties` with
the SHA-1 and resource-pack UUID recorded in the adjacent
`Matcha_Server_ResourcePack_26.2_Vanilla_Terralith_v1_SERVER_PROPERTIES.txt`.

Do not place this resource pack in `world/datapacks`.

## 26.2 validation

- Resource-pack format: `88.0`.
- Active datapack item models: 367/367 resolved.
- Active equipment assets: 12/12 resolved.
- Runtime custom-model-data branches for Matcha foods and DnT charts resolve
  through their models and textures.
- Every visual override in the dependency closure of renamed vanilla items
  and blocks matches the supplied Matcha 1.12 source.
- Dry Hands and Labyrinthine resolve from Minecraft 26.2's official client
  asset index; their audio is therefore intentionally not duplicated here.
